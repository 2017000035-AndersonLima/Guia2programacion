﻿internal class Program
{
    private static void Main(string[] args)
    {
        int c, op;
        double p, i;
        string d = "", f = "";

        p = 650;
        i = p * 1.12;

        Console.Write("Cuantas impresoras va a comprar: ");
        c = int.Parse(Console.ReadLine());

        Console.WriteLine("Como va a pagar?");
        Console.WriteLine("1-efectivo, 2-tarjeta, 3-vale de regalo");
        op = int.Parse(Console.ReadLine());

        switch (op)
        {
            case 1:
                p = i - (i * 0.1);
                d = "10%";
                f = "efectivo";
                break;
            case 2:
                p = i - (i * 0.05);
                d = "5%";
                f = "tarjeta";
                break;
            case 3:
                p = i - (i * 0.15);
                d = "15%";
                f = "vale de regalo";
                break;
            default:
                Console.WriteLine("Escoja una opcion de pago valida");
                p = 0;
                d = "ninguno";
                f = "ninguna";
                break;
        }

        Console.WriteLine($"Cantidad de impresoras adquiridas: {c}");
        Console.WriteLine($"Precio unitario con IVA: Q{i}");
        Console.WriteLine($"Total sin descuento: Q{i * c}");
        Console.WriteLine($"Forma de pago: {f}");
        Console.WriteLine($"Descuento realizado: {d}");
        Console.WriteLine($"Total final: Q{p * c}");
    }
}