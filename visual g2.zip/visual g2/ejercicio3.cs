﻿internal class Program
{
    private static void Main(string[] args)
    {
        Console.WriteLine("dime la letra de tu califiacion");
        char letra=Char.ToUpper(Console.ReadKey().KeyChar);
        switch (letra)
        {
            case 'A':
                Console.WriteLine("EXELENTE");
                break;
            case 'B':
                Console.WriteLine("BUENO");
                break;
            case 'C':
                Console.WriteLine("REGULAR");
                break;
            case 'D':
                Console.WriteLine("DEFICIENTE");
                break;
            case 'F':
                Console.WriteLine("REPROBADO");
                break;
            default:
                Console.WriteLine("Escriba una letra valida");
                break;
        }
    }
}