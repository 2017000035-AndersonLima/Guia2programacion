﻿using System.Runtime.ConstrainedExecution;

internal class Program
{
    private static void Main(string[] args)
    {
        int s, c , p, t, opcion;

        Console.WriteLine("=== ESTADIO DOROTEO GUAMUCH FLORES ===");
        Console.WriteLine();
        Console.WriteLine("Seleccione un sector:");
        Console.WriteLine("1. Palco       - Q300");
        Console.WriteLine("2. Tribuna     - Q100 a Q125");
        Console.WriteLine("3. Preferencia - Q50 a Q75");
        Console.WriteLine("4. Generales   - Q30 a Q50");
        Console.WriteLine();
        Console.Write("Ingrese el número de sector: ");

        if (!int.TryParse(Console.ReadLine(), out s))
        {
            Console.WriteLine("Entrada inválida.");
            return;
        }

        switch (s)
        {
            case 1:
                p = 300;
                Console.WriteLine("Sector: Palco");
                break;
            case 2:
                Console.WriteLine("Seleccione precio de Tribuna:");
                Console.WriteLine("  1. Q100");
                Console.WriteLine("  2. Q125");
                Console.Write("Opción: ");
                if (!int.TryParse(Console.ReadLine(), out opcion)) opcion = 1;
                p = opcion == 1 ? 100 : 125;
                Console.WriteLine("Sector: Tribuna");
                break;
            case 3:
                Console.WriteLine("Seleccione precio de Preferencia:");
                Console.WriteLine("  1. Q50");
                Console.WriteLine("  2. Q75");
                Console.Write("Opción: ");
                if (!int.TryParse(Console.ReadLine(), out opcion)) opcion = 1;
                p = opcion == 1 ? 50 : 75;
                Console.WriteLine("Sector: Preferencia");
                break;
            case 4:
                Console.WriteLine("Seleccione precio de Generales:");
                Console.WriteLine("  1. Q30");
                Console.WriteLine("  2. Q50");
                Console.Write("Opción: ");
                if (!int.TryParse(Console.ReadLine(), out opcion)) opcion = 1;
                p = opcion == 1 ? 30 : 50;
                Console.WriteLine("Sector: Generales");
                break;
            default:
                Console.WriteLine("Sector no válido.");
                p = 0;
                break;
        }

        if (p > 0)
        {
            Console.Write("Ingrese la cantidad de entradas: ");
            if (!int.TryParse(Console.ReadLine(), out c))
            {
                Console.WriteLine("Cantidad inválida.");
                return;
            }

            t = p * c;
            Console.WriteLine();
            Console.WriteLine("=== RESUMEN ===");
            Console.WriteLine("Precio por entrada: Q{0}", p);
            Console.WriteLine("Cantidad de entradas: {0}", c);
            Console.WriteLine("Total a pagar: Q{0}", t);
        }
    }
}