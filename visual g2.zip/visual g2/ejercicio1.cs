﻿internal class Program
{
    private static void Main(string[] args)
    {
        Console.WriteLine("***dias**de**la**semana***");
        Console.WriteLine("dime un numero correspondiente a los dias de la semana");
        int num = Convert.ToInt32(Console.ReadLine());
        switch (num)
        {

            case 1:
                Console.WriteLine("Lunes");
                break;
            case 2:
                Console.WriteLine("Martes");
                break;
            case 3:
                Console.WriteLine("Miercoles");
                break;
            case 4:
                Console.WriteLine("Juves");
                break;
            case 5:
                Console.WriteLine("Viernes");
                break;
            case 6:
                Console.WriteLine("Sabado");
                break;
            case 7:
                Console.WriteLine("Domingo");
                break;
            default:
                Console.WriteLine("Seleccione un Menu");
                break;

        }
    }
}