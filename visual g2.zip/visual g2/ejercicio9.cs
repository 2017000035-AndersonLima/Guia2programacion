﻿internal class Program
{
    private static void Main(string[] args)
    {
        double n, op;
        string m, msj = "";

        Console.WriteLine("=== CONVERSOR DE MEDIDAS ===");
        Console.Write("Ingrese una medida: ");
        n = double.Parse(Console.ReadLine());

        Console.Write("Ingrese su dimensional (metros/pies/centimetros/pulgadas): ");
        m = Console.ReadLine().ToLower();

        switch (m)
        {
            case "metros":
                Console.WriteLine("Escoge a que dimensional quieres convertir:");
                Console.WriteLine("1-pies, 2-centimetros, 3-pulgadas");
                op = int.Parse(Console.ReadLine());
                switch (op)
                {
                    case 1: n = n * 3.28084; msj = "pies"; break;
                    case 2: n = n * 100; msj = "centimetros"; break;
                    case 3: n = n * 39.3701; msj = "pulgadas"; break;
                    default: msj = "opcion no valida"; n = 0; break;
                }
                break;

            case "pies":
                Console.WriteLine("Escoge a que dimensional quieres convertir:");
                Console.WriteLine("1-metros, 2-centimetros, 3-pulgadas");
                op = int.Parse(Console.ReadLine());
                switch (op)
                {
                    case 1: n = n / 3.28084; msj = "metros"; break;
                    case 2: n = n * 30.48; msj = "centimetros"; break;
                    case 3: n = n * 12; msj = "pulgadas"; break;
                    default: msj = "opcion no valida"; n = 0; break;
                }
                break;

            case "centimetros":
                Console.WriteLine("Escoge a que dimensional quieres convertir:");
                Console.WriteLine("1-metros, 2-pies, 3-pulgadas");
                op = int.Parse(Console.ReadLine());
                switch (op)
                {
                    case 1: n = n / 100; msj = "metros"; break;
                    case 2: n = n / 30.48; msj = "pies"; break;
                    case 3: n = n / 2.54; msj = "pulgadas"; break;
                    default: msj = "opcion no valida"; n = 0; break;
                }
                break;

            case "pulgadas":
                Console.WriteLine("Escoge a que dimensional quieres convertir:");
                Console.WriteLine("1-metros, 2-centimetros, 3-pies");
                op = int.Parse(Console.ReadLine());
                switch (op)
                {
                    case 1: n = n / 39.3701; msj = "metros"; break;
                    case 2: n = n * 2.54; msj = "centimetros"; break;
                    case 3: n = n / 12; msj = "pies"; break;
                    default: msj = "opcion no valida"; n = 0; break;
                }
                break;

            default:
                msj = "dimensional no valida";
                break;
        }

        Console.WriteLine($"\nResultado: {n} {msj}");
    }
}