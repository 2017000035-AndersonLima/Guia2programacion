﻿internal class Program
{
    private static void Main(string[] args)
    {
        Console.WriteLine("Escriba dos valores numerico");
        double num1 = Convert.ToDouble(Console.ReadLine());
        double num2 = Convert.ToDouble(Console.ReadLine());

        Console.WriteLine("************");
        Console.WriteLine("Menu Principal");
        Console.WriteLine("************");
        Console.WriteLine("1-Suma");
        Console.WriteLine("2-Resta");
        Console.WriteLine("3-Multi");
        Console.WriteLine("4-Divi");
        Console.WriteLine("5-Salir");
        Console.WriteLine("Digite el valor segun sea la operacion: [ ]");
        int opc = Convert.ToInt32(Console.ReadLine());

        string msj = "";
        double result = 0;
        if (opc > 5)
        {
            Console.WriteLine("opcion erronea");
        }
        else
        {
            switch (opc)
            {
                case 1:
                    msj = "\nSUMA\nla Suma es: ";
                    result = num1 + num2;
                    break;
                case 2:
                    msj = "\nRESTA\nla Resta es: ";
                    result = num1 - num2;
                    break;
                case 3:
                    msj = "\nMULTIPLICACION\nla MULTIPLICACION es: ";
                    result = num1 * num2;
                    break;
                case 4:
                    msj = "\nDIVISION\nla division es: ";
                    result = num1 / num2;
                    break;
                case 5:
                    msj = "saliendo del sistema";
                    break;
            }
            Console.WriteLine(msj);
            Console.Write(result);
        }
        
    }
}