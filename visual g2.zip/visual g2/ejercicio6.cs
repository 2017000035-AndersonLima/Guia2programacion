﻿using System.Runtime.ConstrainedExecution;

internal class Program
{
    private static void Main(string[] args)
    {
        double num, result;

    string msj;

    Console.Write("Digite un angulo en grados: ");
    num = double.Parse(Console.ReadLine());

    num = num * Math.PI / 180;

    Console.WriteLine("************");
    Console.WriteLine("MENU PRINCIPAL");
    Console.WriteLine("1-Seno");
    Console.WriteLine("2-Coseno");
    Console.WriteLine("3-Tangente");
    Console.WriteLine("4-Salir");
    Console.Write("Digite el numero segun su operacion: ");
    int opc =Convert.ToInt32(Console.ReadLine());

    switch (opc)
    {

        case 1:
            msj = "seno del angulo es igual a: ";
            result = Math.Sin(num);
            break;

        case 2:
            msj = "coseno del angulo es igual a: ";
            result = Math.Cos(num);
            break;

        case 3:
            msj = "tangente del angulo es igual a: ";
            result = Math.Tan(num);
            break;

        case 4:
            msj = "Saliendo del sistema";
            result = 0;
            break;

        default:
            msj = "Seleccione una opcion valida";
            result = 0;
            break;
    }

    Console.WriteLine(msj);
    Console.WriteLine(result);
    }
}