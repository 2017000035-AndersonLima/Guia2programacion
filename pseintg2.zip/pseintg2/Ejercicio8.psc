Algoritmo Ejercicio8
		Definir s,c, p,t Como Entero
		
		Escribir "=== ESTADIO DOROTEO GUAMUCH FLORES ==="
		Escribir ""
		Escribir "Seleccione un sector:"
		Escribir "1. Palco       - Q300"
		Escribir "2. Tribuna     - Q100 a Q125"
		Escribir "3. Preferencia - Q50 a Q75"
		Escribir "4. Generales   - Q30 a Q50"
		Escribir ""
		Escribir "Ingrese el n�mero de sector: "
		Leer s
		
		Segun s Hacer
			1:
				p= 300
				Escribir "Sector: Palco"
			2:
				Escribir "Seleccione precio de Tribuna:"
				Escribir "  1. Q100"
				Escribir "  2. Q125"
				Leer opcion
				Si opcion == 1 Entonces
					p=100
				SiNo
					p= 125
				FinSi
				Escribir "Sector: Tribuna"
			3:
				Escribir "Seleccione precio de Preferencia:"
				Escribir "  1. Q50"
				Escribir "  2. Q75"
				Leer opcion
				Si opcion == 1 Entonces
					p=50
				SiNo
					p=75
				FinSi
				Escribir "Sector: Preferencia"
			4:
				Escribir "Seleccione precio de Generales:"
				Escribir "  1. Q30"
				Escribir "  2. Q50"
				Leer opcion
				Si opcion == 1 Entonces
					p=30
				SiNo
					p=50
				FinSi
				Escribir "Sector: Generales"
			De Otro Modo:
				Escribir "Sector no v�lido."
				p=0
		FinSegun
		
		Si p > 0 Entonces
			Escribir "Ingrese la cantidad de entradas: "
			Leer c
			t=p*c
			Escribir ""
			Escribir "=== RESUMEN ==="
			Escribir "Precio por entrada: Q", p
			Escribir "Cantidad de entradas: ", c
			Escribir "Total a pagar: Q", t
		FinSi
		
FinAlgoritmo
