Algoritmo Ejercicio10
	Definir c,op,p,i,im Como Real
	Definir d,f Como Caracter
	p=650
	i=p*1.12
	Escribir "cuantas impresoras va a comprar"
	Leer c
	Escribir "como va a pagar?"
	Escribir "2-tarjeta,1-efectivo,3-vale de regalo"
	Leer op
	Segun op Hacer
		1:
			p=i-(i*0.1)
			d="10%"
			f="efectivo"
		2:
			p=i-(i*0.05)
			d="5%"
			f="tarjeta"
		3:
			p=i-(i*0.15)
			d="15%"
			f="vale de regalo"
		De Otro Modo:
			Escribir "escoja una opcion de pago valida"
			p=0
			d=""
	Fin Segun
	Escribir "cantidad de impresoras adquiridas: ",c
	Escribir "precio unitario de la impresora (con iva): ",i
	Escribir "total sin descuento: ",i*c
	Escribir "forma de pago: ",f
	Escribir "descuento realizado: ",d
	Escribir "total final: ",p*c
FinAlgoritmo
