Algoritmo Ejercicio7
		Definir c Como Caracter
		
		Escribir "Ingrese un car�cter: "
		Leer c
		Segun c Hacer
				'a', 'e', 'i', 'o', 'u','A', 'E', 'I', 'O', 'U':
				Escribir "lo ingresado es un caracter"
				'0', '1', '2', '3', '4','5', '6', '7', '8', '9':
				Escribir "lo ingresado es un valor numerico"
			De Otro Modo:
				Escribir "ingrese algo valido"
		FinSegun
FinAlgoritmo
