Algoritmo Ejecicio6
	Definir num,opc,result Como Real
	Definir msj Como Caracter
	Escribir Sin Saltar"Digite un angulo en grados: "
	Leer num
	num=num* PI / 180
	Escribir "************"
	Escribir "MENU PRINCIPAL"
	Escribir "1-Seno"
	Escribir "2-Coseno"
	Escribir "3-tangente"
	Escribir "4-salir"
	Escribir Sin Saltar "Digite el numero segun su operacion: "
	Leer opc
	
	Segun opc Hacer
		1:
			msj="seno del angulo es igual a: "
			result=sen(num)
		2:
			msj="coseno del angulo es igual a: "
			result=cos(num)
		3:
			msj="tangente del angul es igual a: "
			result=tan(num)
		4:
			msj="Saliendo del sistema"
		De Otro Modo:
			msj="Seleccione una opcion valida"
	Fin Segun
	Escribir msj
	Escribir result
FinAlgoritmo
