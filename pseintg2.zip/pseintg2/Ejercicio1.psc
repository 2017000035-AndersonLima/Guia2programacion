Algoritmo Ejercicio1
	Definir num Como Entero
	Escribir "dime un numero acorde al dia de la semana"
	Leer num
	Segun num Hacer
		1:
			Escribir "Lunes"
		2:
			Escribir "Martes"
		3:
			Escribir "Miercoles"
		4:
			Escribir "Jueves"
		5:
			Escribir "Viernes"
		6:
			Escribir "Sabado"
		7:
			Escribir "Domingo"
		De Otro Modo:
			Escribir "numero no valido"
	Fin Segun
FinAlgoritmo
