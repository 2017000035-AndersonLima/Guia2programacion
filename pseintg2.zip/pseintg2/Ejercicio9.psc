Algoritmo Ejercicio9
	Definir n,op Como Real
	Definir m, msj Como Caracter
	Escribir "conversor de medidas"
	Escribir "dime una medida"
	Leer n
	Escribir "dime su dimensionales"
	Leer m
	Segun m Hacer
		"metros":
			Escribir "escoge a que dimesional quieres convertir"
			Escribir "1-pies,2-centimetros,3-pulgadas"
			Leer op
			Segun op Hacer
				1:
					n=n* 3.28084
					msj="pies"
				2:
					n=n* 100
					msj="centimetros"
				3:
					n=n* 39.3701
					msj="pulgadas"
				De Otro Modo:
					msj="opcion no valida"
					n= 0
			Fin Segun
		"pies":
			Escribir "escoge a que dimesional quieres convertir"
			Escribir "1-metros,2-centimetros,3-pulgadas"
			Leer op
			Segun op Hacer
				1:
					n=n/ 3.28084
					msj="metros"
				2:
					n=n* 30.48
					msj="centimetros"
				3:
					n=n* 12
					msj="pulgadas"
				De Otro Modo:
					msj="opcion no valida"
					n= 0
			Fin Segun
		"centimetros":
			Escribir "escoge a que dimesional quieres convertir"
			Escribir "1-metros,2-pies,3-pulgadas"
			Leer op
			Segun op Hacer
				1:
					n=n/ 100
					msj="metros"
				2:
					n=n/ 30.48
					msj="pies"
				3:
					n=n/ 2.54
					msj="pulgadas"
				De Otro Modo:
					msj="opcion no valida"
					n= 0
			FinSegun
		"pulgadas":
			Escribir "escoge a que dimesional quieres convertir"
			Escribir "1-metros,2-centimetros,3-pies"
			Leer op
			Segun op Hacer
				1:
					n=n/ 39.3701
					msj="metros"
				2:
					n=n* 2.54
					msj="centimetros"
				3:
					n=n/ 12
					msj="pies"
				De Otro Modo:
					msj="opcion no valida"
					n= 0
			FinSegun
		De Otro Modo:
			msj="opcion no valida"
	Fin Segun
	Escribir msj
	Escribir n
FinAlgoritmo
